import { type AuthServerMetadata } from './types.js';
/**
 * Validates the structure of raw authorization server metadata and returns it typed as
 * {@link AuthServerMetadata}.
 *
 * @param data The raw metadata object, e.g. the JSON response from a discovery endpoint.
 * @returns The validated metadata in wire format (snake_case).
 * @throws {MCPAuthAuthServerError} with code `'invalid_server_metadata'` if the metadata is not
 * an object or a checked field has an unexpected type.
 */
export declare const parseAuthServerMetadata: (data: unknown) => AuthServerMetadata;
export type AuthServerValidationResult = {
    /** Human-readable descriptions of the MCP specification violations found in the metadata. */
    errors: string[];
    /** Human-readable descriptions of non-fatal issues found in the metadata. */
    warnings: string[];
};
/**
 * Checks the authorization server metadata against the requirements of the MCP authorization
 * specification (authorization code grant with PKCE `S256`).
 *
 * @param metadata The structurally valid metadata to check.
 * @returns The errors and warnings found. An empty `errors` array means the server is usable.
 */
export declare const validateAuthServerMetadata: (metadata: AuthServerMetadata) => AuthServerValidationResult;
/**
 * Validates resolved authorization server metadata against the MCP specification, logging
 * warnings and throwing on errors.
 *
 * @param metadata The structurally valid metadata to validate.
 * @throws {MCPAuthAuthServerError} with code `'invalid_server_config'` if the metadata violates
 * the MCP authorization specification.
 */
export declare const validateResolvedMetadata: (metadata: AuthServerMetadata) => void;
