/**
 * Base class for all mcp-auth errors.
 *
 * These errors cover configuration and authorization server discovery failures. Token
 * verification failures are intentionally NOT represented here — `MCPAuth#verifyAccessToken`
 * throws the MCP SDK's `OAuthError` instead, because the SDK bearer-auth helpers only map
 * `OAuthError` to proper `401` challenge responses (anything else becomes a `500`).
 */
export declare class MCPAuthError extends Error {
    /**
     * The error code in snake_case format.
     */
    readonly code: string;
    name: string;
    constructor(
    /**
     * The error code in snake_case format.
     */
    code: string, 
    /**
     * A human-readable description of the error.
     */
    message: string);
}
/**
 * Error thrown when there is a configuration issue with mcp-auth, such as an invalid resource
 * identifier or a failed metadata fetch.
 */
export declare class MCPAuthConfigError extends MCPAuthError {
    name: string;
}
export type AuthServerErrorCode = 'invalid_server_metadata' | 'invalid_server_config' | 'missing_jwks_uri';
export declare const authServerErrorDescription: Readonly<Record<AuthServerErrorCode, string>>;
/**
 * Error thrown when there is an issue with the remote authorization server, such as invalid
 * metadata or a configuration that does not satisfy the MCP authorization specification.
 */
export declare class MCPAuthAuthServerError extends MCPAuthError {
    readonly code: AuthServerErrorCode;
    readonly cause?: unknown | undefined;
    name: string;
    constructor(code: AuthServerErrorCode, cause?: unknown | undefined);
}
