import { type JWTVerifyGetKey, type RemoteJWKSetOptions } from 'jose';
import { type AuthServerConfig, type AuthServerMetadata } from './types.js';
/**
 * Holds the runtime state for the single authorization server trusted by an `MCPAuth` instance:
 * the (possibly lazily discovered) server metadata and the remote JWK Set.
 *
 * - For resolved configs (with metadata), the metadata is returned directly; it has already been
 *   validated by the `MCPAuth` constructor.
 * - For discovery configs (issuer + type), the metadata is fetched on first use and validated
 *   when it resolves. The in-flight promise is cached so concurrent calls share a single fetch,
 *   and the cache is reset on failure so a transient discovery error does not stick.
 * - The remote JWK Set instance is created once and reused, so jose's internal caching
 *   (`cooldownDuration`, `cacheMaxAge`) works effectively across requests.
 */
export declare class AuthServerContext {
    #private;
    private readonly config;
    private readonly remoteJwkSetOptions?;
    constructor(config: AuthServerConfig, remoteJwkSetOptions?: RemoteJWKSetOptions | undefined);
    /**
     * The issuer identifier of the trusted authorization server, available without fetching the
     * metadata. Used to reject tokens from unknown issuers before any network request.
     */
    get issuer(): string;
    getMetadata(): Promise<AuthServerMetadata>;
    getJwks(): Promise<JWTVerifyGetKey>;
}
